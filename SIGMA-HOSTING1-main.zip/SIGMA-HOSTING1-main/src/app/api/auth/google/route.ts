import { NextRequest, NextResponse } from "next/server";
import { OAuth2Client } from "google-auth-library";
import { db } from "@/db";
import { users, referrals } from "@/db/schema";
import { eq } from "drizzle-orm";
import { signToken } from "@/lib/auth";
import { nanoid } from "nanoid";

const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

export async function POST(req: NextRequest) {
  try {
    const { credential, referralCode } = await req.json();
    if (!credential) return NextResponse.json({ error: "No credential" }, { status: 400 });

    const ticket = await client.verifyIdToken({ idToken: credential, audience: process.env.GOOGLE_CLIENT_ID });
    const payload = ticket.getPayload();
    if (!payload || !payload.email) return NextResponse.json({ error: "Invalid token" }, { status: 401 });

    const { email, name } = payload;
    let [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);

    if (!user) {
      let username = (name || email.split("@")[0]).replace(/\s+/g, "_").toLowerCase().slice(0, 50);
      const existingUsername = await db.select().from(users).where(eq(users.username, username)).limit(1);
      if (existingUsername.length > 0) username = username + "_" + nanoid(4);

      let referredByUserId: number | undefined;
      if (referralCode) {
        const referrer = await db.select().from(users).where(eq(users.referralCode, referralCode)).limit(1);
        if (referrer.length > 0) referredByUserId = referrer[0].id;
      }

      [user] = await db.insert(users).values({
        username, email, password: nanoid(32), referralCode: nanoid(10),
        referredBy: referredByUserId ?? null, credits: 0,
      }).returning();

      if (referredByUserId) {
        await db.insert(referrals).values({ referrerId: referredByUserId, referredId: user.id, bonusMinutes: 600 });
        const referrer = await db.select().from(users).where(eq(users.id, referredByUserId)).limit(1);
        if (referrer.length > 0) {
          await db.update(users).set({ credits: referrer[0].credits + 600, referralCount: referrer[0].referralCount + 1 }).where(eq(users.id, referredByUserId));
        }
      }
    }

    const token = signToken({ userId: user.id, username: user.username, isAdmin: user.isAdmin });
    const response = NextResponse.json({
      success: true,
      user: { id: user.id, username: user.username, email: user.email, isAdmin: user.isAdmin, credits: user.credits, referralCode: user.referralCode },
      token,
    });
    response.cookies.set("token", token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60, path: "/" });
    return response;
  } catch (error: unknown) {
    console.error("Google auth error:", error);
    return NextResponse.json({ error: "Google authentication failed" }, { status: 500 });
  }
                                                                }
