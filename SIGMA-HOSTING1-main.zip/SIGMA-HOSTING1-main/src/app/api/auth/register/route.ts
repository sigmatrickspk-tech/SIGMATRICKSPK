import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, referrals } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { signToken } from "@/lib/auth";
import { nanoid } from "nanoid";

export async function POST(req: NextRequest) {
  try {
    const { username, email, password, referralCode } = await req.json();
    if (!username || !email || !password) return NextResponse.json({ error: "All fields required" }, { status: 400 });

    const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (existing.length > 0) return NextResponse.json({ error: "Email already exists" }, { status: 400 });

    const existingUsername = await db.select().from(users).where(eq(users.username, username)).limit(1);
    if (existingUsername.length > 0) return NextResponse.json({ error: "Username already taken" }, { status: 400 });

    const hashedPassword = await bcrypt.hash(password, 10);
    const myReferralCode = nanoid(10);
    let referredByUserId: number | undefined;

    if (referralCode) {
      const referrer = await db.select().from(users).where(eq(users.referralCode, referralCode)).limit(1);
      if (referrer.length > 0) referredByUserId = referrer[0].id;
    }

    const [newUser] = await db.insert(users).values({
      username, email, password: hashedPassword, referralCode: myReferralCode,
      referredBy: referredByUserId ?? null, credits: 0,
    }).returning();

    if (referredByUserId) {
      await db.insert(referrals).values({ referrerId: referredByUserId, referredId: newUser.id, bonusMinutes: 600 });
      const referrer = await db.select().from(users).where(eq(users.id, referredByUserId)).limit(1);
      if (referrer.length > 0) {
        await db.update(users).set({ credits: referrer[0].credits + 600, referralCount: referrer[0].referralCount + 1 }).where(eq(users.id, referredByUserId));
      }
    }

    const token = signToken({ userId: newUser.id, username: newUser.username, isAdmin: newUser.isAdmin });
    const response = NextResponse.json({ success: true, user: { id: newUser.id, username: newUser.username, isAdmin: newUser.isAdmin }, token });
    response.cookies.set("token", token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60, path: "/" });
    return response;
  } catch (error: unknown) {
    console.error("Register error:", error);
    return NextResponse.json({ error: "Registration failed" }, { status: 500 });
  }
  }
