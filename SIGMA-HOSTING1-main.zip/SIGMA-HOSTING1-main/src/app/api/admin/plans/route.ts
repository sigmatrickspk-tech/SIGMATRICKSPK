import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { plans } from "@/db/schema";
import { getUserFromRequest } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req.headers);
    if (!payload?.isAdmin) {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }

    const { name, durationDays, priceRs, description } = await req.json();

    const [plan] = await db
      .insert(plans)
      .values({
        name,
        durationDays,
        priceRs,
        description,
      })
      .returning();

    return NextResponse.json({ success: true, plan });
  } catch (error: unknown) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req.headers);
    if (!payload?.isAdmin) {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }

    const { id, name, durationDays, priceRs, description, isActive } =
      await req.json();

    const updateData: Record<string, unknown> = {};
    if (name !== undefined) updateData.name = name;
    if (durationDays !== undefined) updateData.durationDays = durationDays;
    if (priceRs !== undefined) updateData.priceRs = priceRs;
    if (description !== undefined) updateData.description = description;
    if (isActive !== undefined) updateData.isActive = isActive;

    const [updated] = await db
      .update(plans)
      .set(updateData)
      .where(eq(plans.id, id))
      .returning();

    return NextResponse.json({ success: true, plan: updated });
  } catch (error: unknown) {
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
  }
