import { NextResponse } from "next/server";
import { db, pool } from "@/db";
import { plans, users } from "@/db/schema";
import bcrypt from "bcryptjs";
import { nanoid } from "nanoid";
import { eq } from "drizzle-orm";

async function ensureTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username VARCHAR(100) NOT NULL UNIQUE,
      email VARCHAR(255) NOT NULL UNIQUE,
      password TEXT NOT NULL,
      credits INTEGER NOT NULL DEFAULT 0,
      referral_code VARCHAR(20) NOT NULL UNIQUE,
      referred_by INTEGER,
      referral_count INTEGER NOT NULL DEFAULT 0,
      is_admin BOOLEAN NOT NULL DEFAULT false,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS plans (
      id SERIAL PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      duration_days INTEGER NOT NULL,
      price_rs INTEGER NOT NULL,
      description TEXT,
      is_active BOOLEAN NOT NULL DEFAULT true
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS bots (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL,
      name VARCHAR(200) NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'stopped',
      env_vars TEXT,
      files TEXT,
      main_file VARCHAR(255),
      language VARCHAR(50) NOT NULL DEFAULT 'nodejs',
      logs TEXT,
      plan_id INTEGER,
      expires_at TIMESTAMP,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS payments (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL,
      plan_id INTEGER NOT NULL,
      amount INTEGER NOT NULL,
      method VARCHAR(50) NOT NULL,
      transaction_id VARCHAR(255),
      status VARCHAR(20) NOT NULL DEFAULT 'pending',
      phone_number VARCHAR(255),
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS referrals (
      id SERIAL PRIMARY KEY,
      referrer_id INTEGER NOT NULL,
      referred_id INTEGER NOT NULL,
      bonus_minutes INTEGER NOT NULL DEFAULT 600,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS support_tickets (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL,
      type VARCHAR(50) NOT NULL,
      subject VARCHAR(255) NOT NULL,
      message TEXT NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'open',
      admin_response TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );
  `);
}

async function runSeed() {
  await ensureTables();

  const existingPlans = await db.select().from(plans).limit(1);
  if (existingPlans.length === 0) {
    await db.insert(plans).values([
      { name: "1 Day", durationDays: 1, priceRs: 20, description: "24 hours of bot hosting" },
      { name: "3 Days", durationDays: 3, priceRs: 50, description: "3 days of continuous bot hosting" },
      { name: "7 Days", durationDays: 7, priceRs: 100, description: "1 week of non-stop bot hosting" },
      { name: "1 Month", durationDays: 30, priceRs: 300, description: "30 days of premium bot hosting" },
      { name: "1 Year", durationDays: 365, priceRs: 3500, description: "365 days of ultimate bot hosting" }
    ]);
  }

  const existingAdmin = await db.select().from(users).where(eq(users.isAdmin, true)).limit(1);
  if (existingAdmin.length === 0) {
    const hashedPassword = await bcrypt.hash("9908761Hf@", 10);
    await db.insert(users).values({
      username: "admin",
      email: "flyerup11hannan1@gmail.com",
      password: hashedPassword,
      referralCode: nanoid(10),
      isAdmin: true,
      credits: 999999
    });
  }
}

export async function GET() {
  try {
    await runSeed();
    return NextResponse.json({ success: true, message: "Database seeded successfully" });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json({ error: "Seed failed" }, { status: 500 });
  }
}

export async function POST() {
  try {
    await runSeed();
    return NextResponse.json({ success: true, message: "Database seeded successfully" });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json({ error: "Seed failed" }, { status: 500 });
  }
}
