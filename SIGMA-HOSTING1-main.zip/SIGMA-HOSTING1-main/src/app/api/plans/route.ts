import { NextResponse } from "next/server";
import { db } from "@/db";
import { plans } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const allPlans = await db.select().from(plans).where(eq(plans.isActive, true));
    return NextResponse.json(allPlans);
  } catch (error: unknown) {
    console.error("Plans error:", error);
    return NextResponse.json({ error: "Failed to fetch plans" }, { status: 500 });
  }
}
