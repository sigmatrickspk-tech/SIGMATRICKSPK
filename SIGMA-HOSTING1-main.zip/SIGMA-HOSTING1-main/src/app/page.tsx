import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen p-6 text-matrix-green">
      <div className="max-w-6xl mx-auto">
        <div className="text-center py-12">
          <h1 className="text-4xl md:text-6xl font-bold glitch-text">
            SIGMA HOSTING
          </h1>
          <p className="text-xl md:text-2xl text-matrix-blue mt-3">
            24/7 ROBOT
          </p>
          <p className="text-matrix-dim mt-6 max-w-2xl mx-auto">
            Upload your bot files, add environment variables, buy a hosting plan,
            and run your bots 24/7.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
            <Link href="/register" className="hacker-btn text-center">
              REGISTER
            </Link>
            <Link href="/login" className="hacker-btn hacker-btn-blue text-center">
              LOGIN
            </Link>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mt-10">
          <div className="hacker-card p-6">
            <h2 className="text-matrix-blue font-bold text-lg mb-2">24/7 Hosting</h2>
            <p className="text-matrix-dim text-sm">
              Keep your Discord bots and automation bots online all day and night.
            </p>
          </div>

          <div className="hacker-card p-6">
            <h2 className="text-matrix-blue font-bold text-lg mb-2">Crypto + Local Payments</h2>
            <p className="text-matrix-dim text-sm">
              Accept JazzCash, EasyPaisa, Bitcoin, Ethereum, Solana, Tron and more.
            </p>
          </div>

          <div className="hacker-card p-6">
            <h2 className="text-matrix-blue font-bold text-lg mb-2">Referral Rewards</h2>
            <p className="text-matrix-dim text-sm">
              Invite friends and get 10 hours free hosting for every successful signup.
            </p>
          </div>
        </div>

        <div className="mt-12 hacker-card p-6">
          <h2 className="text-2xl font-bold text-matrix-green mb-4">
            Hosting Plans
          </h2>
          <div className="grid md:grid-cols-5 gap-4">
            {[
              { name: "1 Day", price: "Rs.20" },
              { name: "3 Days", price: "Rs.50" },
              { name: "7 Days", price: "Rs.100" },
              { name: "1 Month", price: "Rs.300" },
              { name: "1 Year", price: "Rs.3500" },
            ].map((plan) => (
              <div key={plan.name} className="border border-matrix-border p-4 text-center">
                <div className="text-matrix-blue font-bold">{plan.name}</div>
                <div className="text-2xl text-matrix-yellow mt-2">{plan.price}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
