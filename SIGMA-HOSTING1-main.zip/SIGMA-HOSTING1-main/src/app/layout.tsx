import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "SIGMA HOSTING 24/7 ROBOT — Bot Hosting Platform",
  description: "Deploy and run your bots 24/7 on our secure hacker-grade hosting platform.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="matrix-bg min-h-screen antialiased">{children}</body>
    </html>
  );
}
