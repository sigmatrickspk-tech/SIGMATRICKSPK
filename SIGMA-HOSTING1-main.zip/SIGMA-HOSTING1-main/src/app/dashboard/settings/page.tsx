"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface User {
  id: number;
  username: string;
  email: string;
  credits: number;
  referralCode: string;
  referralCount: number;
  isAdmin: boolean;
  createdAt: string;
}

export default function SettingsPage() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const run = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        window.location.href = "/login";
        return;
      }

      try {
        const res = await fetch("/api/auth/me", {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!res.ok) {
          localStorage.removeItem("token");
          localStorage.removeItem("user");
          window.location.href = "/login";
          return;
        }

        const data = await res.json();
        setUser(data);
      } catch {
        window.location.href = "/login";
      } finally {
        setLoading(false);
      }
    };

    run();
  }, []);

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/";
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-matrix-green">
        [ LOADING SETTINGS... ]
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-matrix-green">Settings</h1>
            <p className="text-matrix-dim text-sm mt-1">
              Manage your account
            </p>
          </div>

          <div className="flex gap-3 flex-wrap">
            <Link href="/dashboard" className="hacker-btn hacker-btn-blue">
              DASHBOARD
            </Link>
            <button onClick={logout} className="hacker-btn hacker-btn-red">
              LOGOUT
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4 mb-8">
          <div className="hacker-card p-5">
            <div className="text-matrix-blue text-sm mb-1">Username</div>
            <div className="text-xl font-bold text-matrix-green">
              {user.username}
            </div>
          </div>

          <div className="hacker-card p-5">
            <div className="text-matrix-blue text-sm mb-1">Email</div>
            <div className="text-sm font-bold text-matrix-yellow break-all">
              {user.email}
            </div>
          </div>

          <div className="hacker-card p-5">
            <div className="text-matrix-blue text-sm mb-1">Credits</div>
            <div className="text-2xl font-bold text-matrix-green">
              {user.credits}
            </div>
          </div>

          <div className="hacker-card p-5">
            <div className="text-matrix-blue text-sm mb-1">Referral Code</div>
            <div className="text-lg font-bold text-matrix-yellow break-all">
              {user.referralCode}
            </div>
          </div>
        </div>

        <div className="hacker-card p-6">
          <h2 className="text-2xl font-bold text-matrix-green mb-4">
            Forgot Password?
          </h2>
          <p className="text-matrix-dim text-sm mb-4">
            If you forgot your password, contact admin directly.
          </p>

          <a
            href="mailto:flyerup11hannan1@gmail.com?subject=Password Reset Request - SIGMA HOSTING"
            className="hacker-btn inline-block"
          >
            CONTACT ADMIN
          </a>
        </div>
      </div>
    </div>
  );
            }
