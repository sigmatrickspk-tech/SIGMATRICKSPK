"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface User {
  id: number;
  username: string;
  email: string;
  credits: number;
  referralCode: string;
  referralCount: number;
  isAdmin: boolean;
}

interface Plan {
  id: number;
  name: string;
  durationDays: number;
  priceRs: number;
  description: string;
}

export default function DashboardPage() {
  const [user, setUser] = useState<User | null>(null);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const run = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        window.location.href = "/login";
        return;
      }

      try {
        const [userRes, plansRes] = await Promise.all([
          fetch("/api/auth/me", {
            headers: { Authorization: `Bearer ${token}` },
          }),
          fetch("/api/plans"),
        ]);

        if (!userRes.ok) {
          localStorage.removeItem("token");
          localStorage.removeItem("user");
          window.location.href = "/login";
          return;
        }

        const userData = await userRes.json();
        setUser(userData);

        if (plansRes.ok) {
          const plansData = await plansRes.json();
          setPlans(plansData);
        }
      } catch {
        window.location.href = "/login";
      } finally {
        setLoading(false);
      }
    };

    run();
  }, []);

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/";
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-matrix-green">
        [ LOADING DASHBOARD... ]
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-matrix-green">
              Welcome, {user.username}
            </h1>
            <p className="text-matrix-dim text-sm mt-1">
              SIGMA HOSTING 24/7 ROBOT dashboard
            </p>
          </div>

          <div className="flex gap-3 flex-wrap">
            <Link href="/dashboard/settings" className="hacker-btn hacker-btn-blue">
              SETTINGS
            </Link>
            {user.isAdmin && (
              <Link href="/admin" className="hacker-btn hacker-btn-red">
                ADMIN PANEL
              </Link>
            )}
            <button onClick={logout} className="hacker-btn">
              LOGOUT
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <div className="hacker-card p-5">
            <div className="text-matrix-blue text-sm mb-1">Credits</div>
            <div className="text-3xl font-bold text-matrix-yellow">
              {user.credits}
            </div>
            <div className="text-matrix-dim text-xs mt-1">minutes</div>
          </div>

          <div className="hacker-card p-5">
            <div className="text-matrix-blue text-sm mb-1">Referral Code</div>
            <div className="text-xl font-bold text-matrix-green break-all">
              {user.referralCode}
            </div>
          </div>

          <div className="hacker-card p-5">
            <div className="text-matrix-blue text-sm mb-1">Referrals</div>
            <div className="text-3xl font-bold text-matrix-green">
              {user.referralCount}
            </div>
          </div>
        </div>

        <div className="hacker-card p-6 mb-8">
          <h2 className="text-2xl font-bold text-matrix-green mb-3">
            Buy Hosting Plan
          </h2>
          <p className="text-matrix-dim text-sm mb-6">
            Payment methods: JazzCash, EasyPaisa, Bitcoin, Ethereum, Solana, Tron.
          </p>

          <div className="grid md:grid-cols-5 gap-4">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className="border border-matrix-border p-4 text-center"
              >
                <div className="text-matrix-blue font-bold">{plan.name}</div>
                <div className="text-2xl text-matrix-yellow mt-2">
                  Rs.{plan.priceRs}
                </div>
                <div className="text-xs text-matrix-dim mt-2">
                  {plan.description}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="hacker-card p-6">
          <h2 className="text-2xl font-bold text-matrix-green mb-3">
            Payment Details
          </h2>
          <div className="space-y-3 text-sm">
            <p>
              <span className="text-matrix-blue">JazzCash / EasyPaisa:</span>{" "}
              <span className="text-matrix-yellow">03244833469</span>
            </p>
            <p>
              <span className="text-matrix-blue">Ethereum / BNB / Polygon:</span>{" "}
              <span className="text-matrix-green break-all">
                0x57aa8B4132DDdbB4D5FE2F874b79B7f84D6ea5Fc
              </span>
            </p>
            <p>
              <span className="text-matrix-blue">Solana:</span>{" "}
              <span className="text-matrix-green break-all">
                CDfvG55wcZM1jR9CpGVxJ2eaS21tQnXrD58chq96pJcq
              </span>
            </p>
            <p>
              <span className="text-matrix-blue">TRON:</span>{" "}
              <span className="text-matrix-green break-all">
                TU3NJjqtHfy4gv1knVmFHopYykACKxq8GH
              </span>
            </p>
            <p>
              <span className="text-matrix-blue">Bitcoin:</span>{" "}
              <span className="text-matrix-green break-all">
                bc1q2rlpyzynauwy25lk7u864c6klyc86tau48s0nn
              </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
            }
