"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface User {
  id: number;
  username: string;
  email: string;
  credits: number;
  referralCode: string;
  referralCount: number;
  isAdmin: boolean;
}

interface Plan {
  id: number;
  name: string;
  durationDays: number;
  priceRs: number;
  description: string;
  isActive?: boolean;
}

export default function AdminPage() {
  const [user, setUser] = useState<User | null>(null);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const run = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        window.location.href = "/login";
        return;
      }

      try {
        const [userRes, plansRes] = await Promise.all([
          fetch("/api/auth/me", {
            headers: { Authorization: `Bearer ${token}` },
          }),
          fetch("/api/plans"),
        ]);

        if (!userRes.ok) {
          localStorage.removeItem("token");
          localStorage.removeItem("user");
          window.location.href = "/login";
          return;
        }

        const userData = await userRes.json();

        if (!userData.isAdmin) {
          window.location.href = "/dashboard";
          return;
        }

        setUser(userData);

        if (plansRes.ok) {
          const plansData = await plansRes.json();
          setPlans(plansData);
        }
      } catch {
        window.location.href = "/login";
      } finally {
        setLoading(false);
      }
    };

    run();
  }, []);

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/";
  };

  const updatePlanField = (
    id: number,
    field: keyof Plan,
    value: string | number
  ) => {
    setPlans((prev) =>
      prev.map((plan) => (plan.id === id ? { ...plan, [field]: value } : plan))
    );
  };

  const savePlan = async (plan: Plan) => {
    const token = localStorage.getItem("token");
    if (!token) return;

    try {
      const res = await fetch("/api/admin/plans", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(plan),
      });

      const data = await res.json();

      if (!res.ok) {
        setMessage(data.error || "Failed to update plan");
        return;
      }

      setMessage(`Plan "${plan.name}" updated successfully`);
      setTimeout(() => setMessage(""), 3000);
    } catch {
      setMessage("Network error while updating plan");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-matrix-green">
        [ LOADING ADMIN PANEL... ]
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-matrix-red">
              SIGMA ADMIN PANEL
            </h1>
            <p className="text-matrix-dim text-sm mt-1">
              Logged in as {user.email}
            </p>
          </div>

          <div className="flex gap-3 flex-wrap">
            <Link href="/dashboard" className="hacker-btn hacker-btn-blue">
              DASHBOARD
            </Link>
            <button onClick={logout} className="hacker-btn hacker-btn-red">
              LOGOUT
            </button>
          </div>
        </div>

        {message && (
          <div className="bg-matrix-green/10 border border-matrix-green text-matrix-green p-3 mb-6 text-sm">
            {message}
          </div>
        )}

        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <div className="hacker-card p-5">
            <div className="text-matrix-blue text-sm mb-1">Admin</div>
            <div className="text-xl font-bold text-matrix-green">
              {user.username}
            </div>
          </div>

          <div className="hacker-card p-5">
            <div className="text-matrix-blue text-sm mb-1">Email</div>
            <div className="text-sm font-bold text-matrix-yellow break-all">
              {user.email}
            </div>
          </div>

          <div className="hacker-card p-5">
            <div className="text-matrix-blue text-sm mb-1">Credits</div>
            <div className="text-2xl font-bold text-matrix-green">
              {user.credits}
            </div>
          </div>
        </div>

        <div className="hacker-card p-6 mb-8">
          <h2 className="text-2xl font-bold text-matrix-green mb-4">
            Edit Plan Prices
          </h2>
          <p className="text-matrix-dim text-sm mb-6">
            You can change plan name, duration and price here anytime.
          </p>

          <div className="space-y-4">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className="border border-matrix-border p-4 rounded-md"
              >
                <div className="grid md:grid-cols-4 gap-3">
                  <input
                    className="hacker-input"
                    value={plan.name}
                    onChange={(e) =>
                      updatePlanField(plan.id, "name", e.target.value)
                    }
                    placeholder="Plan Name"
                  />

                  <input
                    type="number"
                    className="hacker-input"
                    value={plan.durationDays}
                    onChange={(e) =>
                      updatePlanField(
                        plan.id,
                        "durationDays",
                        Number(e.target.value)
                      )
                    }
                    placeholder="Days"
                  />

                  <input
                    type="number"
                    className="hacker-input"
                    value={plan.priceRs}
                    onChange={(e) =>
                      updatePlanField(plan.id, "priceRs", Number(e.target.value))
                    }
                    placeholder="Price Rs"
                  />

                  <button
                    onClick={() => savePlan(plan)}
                    className="hacker-btn"
                  >
                    SAVE
                  </button>
                </div>

                <textarea
                  className="hacker-input mt-3"
                  value={plan.description || ""}
                  onChange={(e) =>
                    updatePlanField(plan.id, "description", e.target.value)
                  }
                  placeholder="Description"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="hacker-card p-6">
          <h2 className="text-2xl font-bold text-matrix-green mb-4">
            Payment Numbers & Wallets
          </h2>

          <div className="space-y-3 text-sm">
            <p>
              <span className="text-matrix-blue">JazzCash:</span>{" "}
              <span className="text-matrix-yellow">03244833469</span>
            </p>
            <p>
              <span className="text-matrix-blue">EasyPaisa:</span>{" "}
              <span className="text-matrix-yellow">03244833469</span>
            </p>
            <p>
              <span className="text-matrix-blue">ETH / BNB / Polygon:</span>{" "}
              <span className="text-matrix-green break-all">
                0x57aa8B4132DDdbB4D5FE2F874b79B7f84D6ea5Fc
              </span>
            </p>
            <p>
              <span className="text-matrix-blue">Solana:</span>{" "}
              <span className="text-matrix-green break-all">
                CDfvG55wcZM1jR9CpGVxJ2eaS21tQnXrD58chq96pJcq
              </span>
            </p>
            <p>
              <span className="text-matrix-blue">TRON:</span>{" "}
              <span className="text-matrix-green break-all">
                TU3NJjqtHfy4gv1knVmFHopYykACKxq8GH
              </span>
            </p>
            <p>
              <span className="text-matrix-blue">Bitcoin:</span>{" "}
              <span className="text-matrix-green break-all">
                bc1q2rlpyzynauwy25lk7u864c6klyc86tau48s0nn
              </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
    }
