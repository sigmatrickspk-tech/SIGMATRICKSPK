"use client";

import { useState } from "react";
import Link from "next/link";
import GoogleSignIn from "@/components/GoogleSignIn";

export default function RegisterPage() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, email, password, referralCode }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Registration failed");
        setLoading(false);
        return;
      }

      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));

      await new Promise((resolve) => setTimeout(resolve, 100));
      window.location.href = "/dashboard";
    } catch {
      setError("Network error");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="text-2xl font-bold text-matrix-green glitch-text">
            🤖 SIGMA HOSTING
          </Link>
          <p className="text-matrix-blue text-sm">24/7 ROBOT</p>
          <p className="text-matrix-dim mt-2 text-sm">// CREATE ACCOUNT</p>
        </div>

        <div className="terminal-window">
          <div className="terminal-header">
            <div className="terminal-dot bg-matrix-red"></div>
            <div className="terminal-dot bg-matrix-yellow"></div>
            <div className="terminal-dot bg-matrix-green"></div>
            <span className="text-xs text-matrix-dim ml-2">register.sh</span>
          </div>

          <div className="p-6">
            {error && (
              <div className="bg-matrix-red/10 border border-matrix-red text-matrix-red p-3 mb-4 text-sm">
                ⚠ {error}
              </div>
            )}

            <GoogleSignIn onError={setError} onLoading={setLoading} />

            <div className="relative w-full flex items-center justify-center my-4">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-matrix-border"></div>
              </div>
              <div className="relative bg-matrix-bg px-4 text-xs text-matrix-dim uppercase tracking-wider">
                or register with email
              </div>
            </div>

            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="text-xs text-matrix-blue uppercase block mb-1">
                  Username
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="hacker-input"
                  placeholder="sigmauser"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-matrix-blue uppercase block mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="hacker-input"
                  placeholder="you@example.com"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-matrix-blue uppercase block mb-1">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="hacker-input"
                  placeholder="••••••••"
                  required
                  minLength={6}
                />
              </div>

              <div>
                <label className="text-xs text-matrix-blue uppercase block mb-1">
                  Referral Code (optional)
                </label>
                <input
                  type="text"
                  value={referralCode}
                  onChange={(e) => setReferralCode(e.target.value)}
                  className="hacker-input"
                  placeholder="friendcode"
                />
              </div>

              <button type="submit" disabled={loading} className="hacker-btn w-full py-3">
                {loading ? "[ CREATING... ]" : "[ REGISTER ]"}
              </button>
            </form>

            <p className="text-center text-matrix-dim text-sm mt-6">
              Already have an account?{" "}
              <Link href="/login" className="text-matrix-green">
                Login here
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
            }
