"use client";

import { useState } from "react";
import Link from "next/link";
import GoogleSignIn from "@/components/GoogleSignIn";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Login failed");
        setLoading(false);
        return;
      }

      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));

      await new Promise((resolve) => setTimeout(resolve, 100));

      if (data.user.isAdmin) {
        window.location.href = "/admin";
      } else {
        window.location.href = "/dashboard";
      }
    } catch {
      setError("Network error");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="text-2xl font-bold text-matrix-green glitch-text">
            🤖 SIGMA HOSTING
          </Link>
          <p className="text-matrix-blue text-sm">24/7 ROBOT</p>
          <p className="text-matrix-dim mt-2 text-sm">// ACCESS TERMINAL</p>
        </div>

        <div className="terminal-window">
          <div className="terminal-header">
            <div className="terminal-dot bg-matrix-red"></div>
            <div className="terminal-dot bg-matrix-yellow"></div>
            <div className="terminal-dot bg-matrix-green"></div>
            <span className="text-xs text-matrix-dim ml-2">login.sh</span>
          </div>

          <div className="p-6">
            {error && (
              <div className="bg-matrix-red/10 border border-matrix-red text-matrix-red p-3 mb-4 text-sm">
                ⚠ {error}
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="text-xs text-matrix-blue uppercase block mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="hacker-input"
                  placeholder="you@example.com"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-matrix-blue uppercase block mb-1">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="hacker-input"
                  placeholder="••••••••"
                  required
                />
              </div>

              <button type="submit" disabled={loading} className="hacker-btn w-full py-3">
                {loading ? "[ AUTHENTICATING... ]" : "[ LOGIN ]"}
              </button>
            </form>

            <GoogleSignIn onError={setError} onLoading={setLoading} />

            <div className="mt-4 text-center text-sm">
              <a
                href="mailto:flyerup11hannan1@gmail.com?subject=Forgot Password - SIGMA HOSTING"
                className="text-matrix-yellow underline"
              >
                Forgot password? Contact admin
              </a>
            </div>

            <p className="text-center text-matrix-dim text-sm mt-6">
              No account?{" "}
              <Link href="/register" className="text-matrix-green">
                Register here
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
                  }
