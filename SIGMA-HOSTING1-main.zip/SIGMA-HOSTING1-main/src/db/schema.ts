import { pgTable, text, integer, boolean, timestamp, serial, varchar } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  credits: integer("credits").notNull().default(0),
  referralCode: varchar("referral_code", { length: 20 }).notNull().unique(),
  referredBy: integer("referred_by"),
  referralCount: integer("referral_count").notNull().default(0),
  isAdmin: boolean("is_admin").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const plans = pgTable("plans", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  durationDays: integer("duration_days").notNull(),
  priceRs: integer("price_rs").notNull(),
  description: text("description"),
  isActive: boolean("is_active").notNull().default(true),
});

export const bots = pgTable("bots", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("stopped"),
  envVars: text("env_vars"),
  files: text("files"),
  mainFile: varchar("main_file", { length: 255 }),
  language: varchar("language", { length: 50 }).notNull().default("nodejs"),
  logs: text("logs"),
  planId: integer("plan_id"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  planId: integer("plan_id").notNull(),
  amount: integer("amount").notNull(),
  method: varchar("method", { length: 50 }).notNull(),
  transactionId: varchar("transaction_id", { length: 255 }),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  phoneNumber: varchar("phone_number", { length: 20 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: integer("referrer_id").notNull(),
  referredId: integer("referred_id").notNull(),
  bonusMinutes: integer("bonus_minutes").notNull().default(600),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  message: text("message").notNull(),
  status: varchar("status", { length: 20 }).notNull().default("open"),
  adminResponse: text("admin_response"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
