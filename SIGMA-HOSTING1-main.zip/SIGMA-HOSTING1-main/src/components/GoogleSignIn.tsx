"use client";
import { useEffect, useCallback } from "react";

declare global {
  interface Window {
    google?: {
      accounts: {
        id: {
          initialize: (config: { client_id: string; callback: (response: { credential: string }) => void }) => void;
          renderButton: (element: HTMLElement, config: { theme?: string; size?: string; text?: string; shape?: string; width?: number }) => void;
        };
      };
    };
  }
}

interface GoogleSignInProps {
  referralCode?: string;
  onError?: (error: string) => void;
  onLoading?: (loading: boolean) => void;
}

export default function GoogleSignIn({ referralCode, onError, onLoading }: GoogleSignInProps) {
  const handleCredentialResponse = useCallback(async (response: { credential: string }) => {
    onLoading?.(true);
    try {
      const res = await fetch("/api/auth/google", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ credential: response.credential, referralCode: referralCode || "" }),
      });
      const data = await res.json();
      if (!res.ok) { onError?.(data.error || "Google login failed"); onLoading?.(false); return; }
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
      await new Promise(resolve => setTimeout(resolve, 100));
      if (data.user.isAdmin) { window.location.href = "/admin"; } else { window.location.href = "/dashboard"; }
    } catch { onError?.("Network error"); onLoading?.(false); }
  }, [referralCode, onError, onLoading]);

  useEffect(() => {
    const clientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID;
    if (!clientId) return;
    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.defer = true;
    script.onload = () => {
      if (window.google) {
        window.google.accounts.id.initialize({ client_id: clientId, callback: handleCredentialResponse });
        const buttonDiv = document.getElementById("google-signin-button");
        if (buttonDiv) {
          window.google.accounts.id.renderButton(buttonDiv, { theme: "filled_black", size: "large", text: "continue_with", shape: "rectangular", width: 300 });
        }
      }
    };
    document.body.appendChild(script);
    return () => { const s = document.querySelector('script[src="https://accounts.google.com/gsi/client"]'); if (s) s.remove(); };
  }, [handleCredentialResponse]);

  if (!process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID) return null;

  return (
    <div className="w-full flex flex-col items-center">
      <div className="relative w-full flex items-center justify-center my-4">
        <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-matrix-border"></div></div>
        <div className="relative bg-matrix-bg px-4 text-xs text-matrix-dim uppercase tracking-wider">or continue with</div>
      </div>
      <div id="google-signin-button" className="flex justify-center"></div>
    </div>
  );
}
